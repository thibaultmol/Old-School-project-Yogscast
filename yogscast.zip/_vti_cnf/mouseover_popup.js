vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|21 Nov 2008 12:07:18 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|
vti_author:SR|SabertoothZ77\\Gebruiker
vti_modifiedby:SR|SabertoothZ77\\Gebruiker
vti_timecreated:TR|21 Nov 2008 12:07:18 -0000
vti_cacheddtm:TX|21 Nov 2008 12:07:18 -0000
vti_filesize:IR|6552
